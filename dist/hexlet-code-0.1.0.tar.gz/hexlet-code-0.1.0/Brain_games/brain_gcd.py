import random
import prompt
def main():
    print("Welcome to the Brain Games!")
    name = prompt.string("May I have your name? ")
    print("Hello, {}!".format(name))
    print("Find the greatest common divisor of given number.")
    for i in range(0, 3):
        first_num = random.randint(1, 100)
        second_num = random.randint(1, 100)
        while first_num != 0 and second_num != 0:    
            if first_num > second_num:
                rem_div1 = first_num % second_num
                if rem_div1 == 0:
                    true_answer = second_num
                    break
            else:
                rem_div2 = second_num % first_num
                if rem_div2 == 0:
                    true_answer = first_num
                    break
        true_answer = rem_div1 + rem_div2
        print("Question: {} {}".format(first_num, second_num))
        answer = float(input("Your answer: "))
        if answer == true_answer:
            print("Correct!")
        else:
            print("'{}' is wrong answer ;(. Correct answer was '{}'\nLet's try again, {}".format(answer, true_answer, name))
            break
        if i == 2:
            print("Congratulations, {}".format(name))
    if __name__ == "__main__":
        main()


                    


